<?php
	echo "Welcome!!!!";  // all good!
?>