
https://github.com/dccircuit/IGME-235-Fall-2019/blob/master/exercises/1-3.md
https://github.com/dccircuit/IGME-235-Fall-2019/blob/master/sessions/1-3.md
